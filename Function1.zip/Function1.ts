//func defination
function fun(): void   //1   not going to accept or return anything
{
    console.log("Inside Fun");
}

fun(); //func call

/**************************************************************************************************************************************** */

function gun(no : number) //2  gonna accpet value but not return anything
{
    console.log("Inside gun : " +no);
}

gun(11); //func argument

/****************************************************************************************************************************************** */

function sun(no:number):number //3  taken int as a params and returning value 
{
    var i : number=no; //local variables
    i++;
    return i;
}

var ret:number=0;
var a:number=10;
ret=sun(a); //func call
console.log("The return value is: " +ret);
