function Demo(no1:number,no2:number,no3 ?:number) //Optional arg (?)
{
    console.log("Inside Demo");
   // console.log("Value of no1: "+no1);
   // console.log("Value of no2: "+no2);
   // console.log("Value of no3: "+no3);

   console.log("Value of no1: " +no1);
   console.log("Value of no2: " +no2);
   if(no3!=undefined)
   {
       console.log("Value of no3: " +no3);
   }
    
}

//Demo(10,11,12); //no1=10,no2=11,no3=12
Demo(10,11); //no1=10,no2=11,no3=undefined