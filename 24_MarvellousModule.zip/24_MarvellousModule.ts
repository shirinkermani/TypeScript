import { Employee } from "./23_MarvellousModule";
let empObj = new Employee("Piyush", 11);

empObj.displayEmployee();