// Create array and then initialise
var arr1:number[];
arr1 = [1, 2, 3, 4, 5];

// Create and initialise the array
var arr2:number[] = [11, 21, 51, 101]; 

// Create array using Array class object
var arr3:number[] = new Array(4)  
arr3 = [1,2,3,4];
 
// Traverse array using for loop
for(var i = 0; i < arr3.length; i++) 
{ 
   console.log(arr3[i]); 
}

// Createing array of strings
var batches:string[] = new Array("PPA","UNIX","LB","ANGULAR"); 

for(var i = 0;i<batches.length;i++) 
{ 
   console.log(batches[i]); 
}

