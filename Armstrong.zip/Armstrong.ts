// var no:153;
// var ret=0;
// ret = chkArmstrong(no)

// console.log("It is a armstrong number " +ret)
// function chkArmstrong(arm:number):number{
//     let d: string[];
//     let i: number;
    
//     for(let i = 0; i<d.length; i++) {
//         sum = sum + Math.pow(d[i], 3)
//      }
//      if(sum == c) {
//          console.log("armstrong")
//      }
//      else {
//          console.log("not a armstrong")
//      }
     
//     return no;
// }
    
    
//     console.log(chkArmstrong);





    




// function three_digit_armstrong_number() 
// {
//  for (var i = 1; i < 10; ++i) 
//  {
//    for (var j = 0; j < 10; ++j) 
//      {
//         for (var k = 0; k < 10; ++k)
//         {
//           var pow = (Math.pow(i,3) + Math.pow(j,3) + Math.pow(k,3));
//           var plus = (i * 100 + j * 10 +  k);
//           if (pow == plus) 
//            {     
//              console.log(pow);
//             }
//          }
//        }
//     }
//   }
// three_digit_armstrong_number();


