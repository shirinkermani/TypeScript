var arr:number[]= [23,89,6,29,56,45,77,32];
   var ret=0;
   ret=Maximum(arr);
   console.log("The Second largest number is: " +ret);

function Maximum(arr:Array<number>):number
{
    arr.sort();
    return arr[arr.length-2];
    
    

   

}