var no1:number=10; //1
var no2:number=11; //2
var ret:number=0;  //3

ret = Addition(no1,no2); //4 //func call //9
console.log("Addition is: " +ret);//10

function Addition(value1:number,value2:number):number //5
{
   var ans:number=0; //6
   ans = value1+value2; //7
   return ans; //8
}