function Display(value : number): void //3 //value is input argument and number is parameter
{
    console.log("Parameter is: " +value); //4    
}

var no: number=11; //1 step                                                               
Display(no); //2