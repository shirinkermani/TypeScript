
   var arr:number[]= [23,89,6,29,56,45,77,32];
   var ret=0;
   ret=Maximum(arr);
   console.log("The largest number is: " +ret);

function Maximum(arr:Array<number>):number
{
    var largest=0;
    var i;
    for(i=0;i<8;i++)
    {
        if(arr[i]>largest)
        {
            largest=arr[i];
        }
    }
    return largest;

   

}