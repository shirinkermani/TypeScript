var no: number=11;
var str:string = "Hello World";
console.log(str);
console.log(no);