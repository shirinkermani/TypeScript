function chkString():void{
    var string = "foo";
    var substring = "oo";
    
    console.log(string.indexOf(substring) !== -1);
}