class Circle
{
    Radius:number;
    PI:number;
    
   

    constructor(a:number) 
    {
        
        this.Radius=a;
        this.PI=3.14;
    }

    Area()
    {
        var Ans:number=0; 
        Ans=this.PI*this.Radius*this.Radius;
        return Ans;
    }


}

var obj1=new Circle(10); 
var obj2=new Circle(20); 

var Ret:number=0;

Ret=obj1.Area(); 
console.log("Area is : " +Ret);

Ret=obj2.Area(); 
console.log("Area is : " +Ret);



class CircleX extends Circle
{
    constructor(a:number)
    {
        super(a);
        this.PI=3.14;
    }
    Circumference()
    {
        super.Area();
        var Ans:number=0; 
        Ans=2*this.PI*this.Radius;
        return Ans;
    }

}

var obj3=new CircleX(10); 
var obj4=new CircleX(20); 

var Ret:number=0;

Ret=obj3.Circumference(); 
console.log("Circumference is : " +Ret);

Ret=obj4.Circumference(); 
console.log("Circumference is : " +Ret);


