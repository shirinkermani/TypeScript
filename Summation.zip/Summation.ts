var arr:number[]= [23,6,7,4,5,7];
   var ret=0;
   ret=Addition(arr);
   console.log("The Addition is: " +ret);

function Addition(arr:Array<number>):number
{
   var sum=0;
    for(var i=0;i<arr.length;i++)
    {
        sum=sum+arr[i];
    }

    return sum;
}