var str1 = "Hello";
console.log(str1);
console.log(typeof str1); // typeof checks the datatype of the variable

var no=11;
console.log(no);
console.log(typeof no);  

var bool=true;
console.log(bool);
console.log(typeof bool);
                                              