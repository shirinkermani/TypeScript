function main():void
{ 
    var p=11;
    var bret:boolean;
    bret=chkPrime(p);

    if(bret==false)
    {
        console.log("It is not a prime number");
    }
    else
    {
        console.log("It is a prime number");
    }
}
function chkPrime(Value1:number):boolean
{
    var i=0;
    var bret:boolean;
    for(i=2;i<Value1;i++)
    {
        if(Value1%i==0)
        {
           bret=false;
           return bret;
        }

    }
    
}
main();