var message:string = "Marvellous Infosystems Web Development" 
console.log(message) 